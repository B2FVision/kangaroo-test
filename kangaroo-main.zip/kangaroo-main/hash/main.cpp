#include <iostream>
#include <vector>
#include <iomanip>
#include <sstream>
#include "sha256.h"
#include "ripemd160.h"

// Função para converter uma string hexadecimal em bytes
std::vector<uint8_t> hexToBytes(const std::string& hex) {
    std::vector<uint8_t> bytes;
    for (size_t i = 0; i < hex.length(); i += 2) {
        std::string byteString = hex.substr(i, 2);
        uint8_t byte = (uint8_t) strtol(byteString.c_str(), nullptr, 16);
        bytes.push_back(byte);
    }
    return bytes;
}

// Função para converter bytes para uma string hexadecimal
std::string bytesToHex(const uint8_t* bytes, size_t length) {
    std::ostringstream oss;
    for (size_t i = 0; i < length; i++) {
        oss << std::hex << std::setw(2) << std::setfill('0') << (int) bytes[i];
    }
    return oss.str();
}

int main() {
    std::string publicKeyHex = "024ee2be2d4e9f92d2f5a4a03058617dc45befe22938feed5b7a6b7282dd74cbdd";

    // Converter a chave pública de hexadecimal para bytes
    std::vector<uint8_t> publicKey = hexToBytes(publicKeyHex);

    // Calcular o hash SHA256 da chave pública
    uint8_t sha256Hash[32];
    sha256(publicKey.data(), publicKey.size(), sha256Hash);

    // Calcular o hash RIPEMD160 do resultado do SHA256
    uint8_t ripemd160Hash[20];
    ripemd160(sha256Hash, 32, ripemd160Hash);

    // Converter o resultado final para hexadecimal
    std::string hash160Hex = bytesToHex(ripemd160Hash, 20);

    // Imprimir o resultado
    std::cout << "Hash160: " << hash160Hex << std::endl;

    return 0;
}
