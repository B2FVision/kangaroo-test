#ifndef RANDOM_H
#define RANDOM_H

double rnd();
unsigned long rndl();
void rseed(unsigned long seed);

#endif
